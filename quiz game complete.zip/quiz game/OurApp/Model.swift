//
//  Model.swift
//  OurApp
//
//  Created by Davide Castaldi on 07/12/22.
//

import Foundation
import SwiftUI

struct Game: Identifiable {
    
    var id = UUID()
    var question: String
    var answer: String
}
/*
struct Answers: Identifiable {
    
    var id = UUID()
    var tapped: Bool
}
*/
