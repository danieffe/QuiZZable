//
//  OurAppApp.swift
//  OurApp
//
//  Created by Davide Castaldi on 07/12/22.
//

import SwiftUI

@main
struct OurAppApp: App {
    var body: some Scene {
        //to show the game view
        WindowGroup {
            GameView(equations: linearEquations.equationsArray[0])
        }
    }
}
