//
//  Data.swift
//  OurApp
//
//  Created by Davide Castaldi on 07/12/22.
//

import Foundation
import SwiftUI

class LinearEquations: ObservableObject {
    
    @Published var equationsArray = [
        
        Game(question: "Solve the following equation: \n\n2x+6 = 0", answer: "x = -3"), // x = -3
        Game(question: "Solve the following equation: \n\n5x-11 = 3x+9", answer: "x = 10"), //x = 10
        Game(question: "Solve the following equation: \n\n9-2(x-5) = x+10 ", answer: "x = 3"), // x = 3
    ]
}

var linearEquations = LinearEquations()
