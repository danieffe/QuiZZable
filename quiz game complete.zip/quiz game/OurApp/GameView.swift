//
//  GameView.swift
//  OurApp
//
//  Created by Davide Castaldi on 07/12/22.
//

import SwiftUI

struct GameView: View {
    
    @ObservedObject var myEquation = linearEquations
    
    @State var didTapAnswer1: Bool = false
    @State var didTapAnswer2: Bool = false
    @State var didTapAnswer3: Bool = false
    @State var didTapAnswer4: Bool = false
    @State var didTapContinue: Bool = false
    @State var solution: String = "No answer"
    @State var solutionViewIsPresented = false
    @State var correctViewIsPresented = false
    
    var equations: Game
    var body: some View {
        NavigationStack {
            ZStack {
                //background of application
                Color.black.opacity(0.9)
                    //.ignoresSafeArea() //if we want to get rid of that white
                //profile picture circle, it is behind the rectangle
                Circle()
                    .fill(Color("dark purple"))
                    .opacity(0.5)
                    .frame(width: 120, height: 120)
                    .padding(.bottom, 600)
                //Where the question and answers will be placed
                VStack {
                    Rectangle()
                        .fill(Color("dark purple")) // placeholder for true color
                        .opacity(0.5)
                        .frame(width: 300, height: 550)
                        .cornerRadius(40)
                        .padding(.bottom, 80)
                }
                //profile picture must be in this ZStack or else it goes below rectangle
                VStack {
                    Image("pp1")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: 105, height: 105)
                        .clipShape(Circle())
                        .shadow(radius: 20)
                        .padding(.bottom, 600)
                }
                //question
                ForEach(myEquation.equationsArray) { equation in
                    Text(equations.question)
                        .font(.title2)
                        .multilineTextAlignment(.center)
                        .foregroundColor(.white)
                        .padding(.bottom, 350)
                }
                //this is the continue button
                ZStack {
                    Rectangle()
                        .fill(Color("brighter purple")) // placeholder for true color
                        .frame(width: 300, height: 80)
                        .cornerRadius(40)
                        .padding(.top, 600)
                    VStack {
                        Button {
                            didTapContinue = true;
                            if(solution == equations.answer) {
                                correctViewIsPresented = true
                                //1 more question or we go to the "end quiz" view?
                                //NavigationLink(destination: CorrectAnswerView())
                            }
                            else if (solution == "No answer") {
                                solutionViewIsPresented = false
                            }
                            else {
                                solutionViewIsPresented = true
                            }
                        } label: {
                            Text("Continue")
                                .font(.title)
                                .foregroundColor(.white)
                                .frame(width: 280, height: 80)
                        }
                        .buttonStyle(.bordered)
                        .controlSize(.small)
                        .padding(.top, 600)
                        .sheet(isPresented: $solutionViewIsPresented) {
                            SolutionView()
                        }
                        //modal is placeholder or we can do that after modal pops up, in the mean time next view is presented behind modal (maybe ugly UX/UI)
                        .sheet(isPresented: $correctViewIsPresented) {
                            CorrectAnswerView()
                        }
                    }
                }
                //THESE ARE FOR ANSWERS
                Group {
                    //Each and every answer has a ZStack for self centering
                    ZStack {
                        //Answer 1
                        Rectangle()
                            .fill(Color("brighter purple")) // placeholder for true color
                            .frame(width: 250, height: 55)
                            .cornerRadius(40)
                            .padding(.bottom, 80)
                        //clickable button
                        VStack {
                            Button {
                                /*logic for all answer buttons:
                                 when an answer is pressed it automatically deselect every other answer previously selected, then copies in a variable the answer.
                                 */
                                if(!didTapAnswer1) {
                                    didTapAnswer1 = true
                                    didTapAnswer2 = false
                                    didTapAnswer3 = false
                                    didTapAnswer4 = false
                                    solution = "x = 5"
                                }
                                //It also considers the case of tapping the same answer again
                                else {
                                    didTapAnswer1 = false
                                    solution = "No answer"
                                }
                            } label: {
                                Text("x = 5")
                                    .font(.title3)
                                    .foregroundColor(.white)
                                    .frame(width: 250, height: 55)

                            }
                            //this is the part that highlights the selected choice according to the button state
                            .background(didTapAnswer1 ? Color.blue.opacity(0.3) : Color("brighter purple"))
                            .cornerRadius(40)
                            .padding(.bottom, 80)
                        }
                    }
                    ZStack {
                        //Answer 2
                        Rectangle()
                            .fill(Color("brighter purple")) // placeholder for true color
                            .frame(width: 250, height: 55)
                            .cornerRadius(40)
                            .padding(.top, 60)
                        //clickable button
                        VStack {
                            Button {
                                if(!didTapAnswer2) {
                                    didTapAnswer2 = true
                                    didTapAnswer1 = false
                                    didTapAnswer3 = false
                                    didTapAnswer4 = false
                                    solution = "x = 1"
                                }
                                else {
                                    didTapAnswer2 = false
                                    solution = "No answer"
                                }
                            } label: {
                                Text("x = 1")
                                    .font(.title3)
                                    .foregroundColor(.white)
                                    .frame(width: 250, height: 55)
                            }
                            .background(didTapAnswer2 ? Color.blue.opacity(0.3) : Color("brighter purple"))
                            .cornerRadius(40)
                            .padding(.top, 60)
                        }
                    }
                    ZStack {
                        //Answer 3
                        Rectangle()
                            .fill(Color("brighter purple")) // placeholder for true color
                            .frame(width: 250, height: 55)
                            .cornerRadius(40)
                            .padding(.top, 200)
                        //clickable button
                        VStack {
                            Button {
                                if(!didTapAnswer3) {
                                    didTapAnswer3 = true
                                    didTapAnswer1 = false
                                    didTapAnswer2 = false
                                    didTapAnswer4 = false
                                    solution = "x = -3"
                                }
                                else {
                                    didTapAnswer3 = false
                                }
                            } label: {
                                Text("x = -3")
                                    .font(.title3)
                                    .foregroundColor(.white)
                                    .frame(width: 250, height: 55)
                            }
                            .background(didTapAnswer3 ? Color.blue.opacity(0.3) : Color("brighter purple"))
                            .cornerRadius(40)
                            .padding(.top, 200)
                        }
                    }
                    ZStack {
                        //Answer 4
                        Rectangle()
                            .fill(Color("brighter purple")) // placeholder for true color
                            .frame(width: 250, height: 55)
                            .cornerRadius(40)
                            .padding(.top, 340)
                        //clickable button
                        VStack {
                            Button {
                                if(!didTapAnswer4) {
                                    didTapAnswer4 = true
                                    didTapAnswer1 = false
                                    didTapAnswer2 = false
                                    didTapAnswer3 = false
                                    solution = "x = -2"
                                }
                                else {
                                    didTapAnswer4 = false
                                    solution = "No answer"
                                }
                            } label: {
                                Text("x = -2")
                                    .font(.title3)
                                    .foregroundColor(.white)
                                    .frame(width: 250, height: 55)
                            }
                            .background(didTapAnswer4 ? Color.blue.opacity(0.3) : Color("brighter purple"))
                            .cornerRadius(40)
                            .padding(.top, 340)
                        }
                    }
                }
            }
        }
    }
}

struct GameView_Previews: PreviewProvider {
    static var previews: some View {
        GameView(equations: linearEquations.equationsArray[0])
    }
}
