//
//  Alisio_projectApp.swift
//  Alisio_project4OT
//
//  Created by Aly on 13/12/22.
//

import SwiftUI

@main
struct Alisio_projectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
