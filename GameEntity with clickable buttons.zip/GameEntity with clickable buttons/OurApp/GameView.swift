//
//  GameView.swift
//  OurApp
//
//  Created by Davide Castaldi on 07/12/22.
//

import SwiftUI

struct GameView: View {
    
    @ObservedObject var myEquation = linearEquations
    
    var Continue = false
    
    var equation: Game
    var body: some View {
        
        ZStack {
            //background of application
            Color(.black)
                .opacity(0.8)
    
            //Where the question and answers will be placed
            VStack {
                Rectangle()
                    .fill(Color(.orange)) // placeholder for true color
                    .frame(width: 300, height: 550)
                    .cornerRadius(40)
                    .padding(.bottom, 80)
            }
            //question
            Text(equation.question)
                .font(.title2)
                .multilineTextAlignment(.center)
                .foregroundColor(.black)
                .padding(.bottom, 350)
            //this is the continue button
            ZStack {
                Rectangle()
                    .fill(Color(.orange)) // placeholder for true color
                    .frame(width: 300, height: 80)
                    .cornerRadius(40)
                    .padding(.top, 600)
                
                VStack {
                    Button {
                        //
                    } label: {
                        Text("Continue")
                            .font(.title)
                            .foregroundColor(.black)
                            .frame(width: 300, height: 80)
   
                    }
                    .contentShape(Rectangle())
                    .padding(.top, 600)
                }
            }
            //profile picture
            ZStack {
                Circle()
                    .fill(Color(.orange))
                    .frame(width: 120, height: 120)
                    .padding(.bottom, 600)
                VStack {
                    Image("pp1")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: 105, height: 105)
                        .clipShape(Circle())
                        .shadow(radius: 20)
                        .padding(.bottom, 600)
                }
            }
            //THESE ARE FOR ANSWERS
            Group {
                //Each and every answer has a ZStack for self centering
                ZStack {
                    //Answer 1
                    Rectangle()
                        .fill(Color(.white)) // placeholder for true color
                        .frame(width: 250, height: 55)
                        .cornerRadius(40)
                        .padding(.bottom, 80)
                    //clickable button
                    VStack {
                         Button {
                         } label: {
                             Text("x = 5")
                                 .font(.title3)
                                 .foregroundColor(.black)
                                 .frame(width: 250, height: 53)
                         }
                         .contentShape(Rectangle())
                         .padding(.bottom, 80)
                    }
                }
                
                ZStack {
                    //Answer 2
                    Rectangle()
                        .fill(Color(.white)) // placeholder for true color
                        .frame(width: 250, height: 55)
                        .cornerRadius(40)
                        .padding(.top, 60)
                    //clickable button
                    VStack {
                         Button {
                         } label: {
                             Text("x = 1")
                                 .font(.title3)
                                 .foregroundColor(.black)
                                 .frame(width: 250, height: 55)
                         }
                         .contentShape(Rectangle())
                         .padding(.top, 60)
                    }
                }
                
                ZStack {
                    //Answer 3
                    Rectangle()
                        .fill(Color(.white)) // placeholder for true color
                        .frame(width: 250, height: 55)
                        .cornerRadius(40)
                        .padding(.top, 200)
                    //clickable button
                    VStack {
                        Button {
                        } label: {
                            Text("x = -3")
                                .font(.title3)
                                .foregroundColor(.black)
                                .frame(width: 250, height: 55)
                        }
                        .contentShape(Rectangle())
                        .padding(.top, 200)
                    }
                }
                
                ZStack {
                    //Answer 4
                    Rectangle()
                        .fill(Color(.white)) // placeholder for true color
                        .frame(width: 250, height: 55)
                        .cornerRadius(40)
                        .padding(.top, 340)
                    //clickable button
                    VStack {
                         Button {
                         } label: {
                             Text("x = 5")
                                 .font(.title3)
                                 .foregroundColor(.black)
                                 .frame(width: 250, height: 55)
                         }
                         .contentShape(Rectangle())
                         .padding(.top, 340)
                    }
                }
            }
        }
    }
}

struct GameView_Previews: PreviewProvider {
    static var previews: some View {
        GameView(equation: linearEquations.equationsArray[0])
    }
}
