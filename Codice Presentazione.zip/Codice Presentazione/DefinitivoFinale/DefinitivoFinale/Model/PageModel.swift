import Foundation

struct Page: Identifiable, Equatable {
    let id = UUID()
    var name: String
    var description: String
    var imageUrl: String
    var tag: Int
    
    static var samplePage = Page(name: "Title Example", description: "This is a sample description for the purpose of debugging", imageUrl: "work", tag: 0)
    
    static var samplePages: [Page] = [
        Page(name: "Learn with us", description:"Learn in an alternative way wherever you want. ", imageUrl: "mascotte", tag: 0),
        Page(name: "Test your knowledge", description: "Test your knowledge answering questions and you will win fantastic rewards", imageUrl: "mascotte", tag: 1),
        Page(name: "Customize your experience", description: "You choose the subjects you want to practice on!!!", imageUrl: "mascotte", tag: 2),
    ]
}
