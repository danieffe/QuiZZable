//
//  ProfileView.swift
//  Task3
//
//  Created by Daniele Fontana on 09/12/22.
//

import Foundation
import SwiftUI
import CoreData

struct ProfileView: View {
    
    var defaults = UserDefaults.standard
//    @State var testo: String = UserDefaults.standard.string(forKey: "TEXT_KEY") ?? ""
    @State var showEdit=true
    @AppStorage("TEXT_KEY") var testo: String = ""
    @State var inputText: String = ""
    @State var cambioTesto: String = ""
    @State var nomeuser = UserDefaults.standard.string(forKey: "inome")  ?? ""
    @State var icona = UserDefaults.standard.string(forKey: "icona")  ?? ""
    @State var balance = UserDefaults.standard.integer(forKey: "Bilancio")
    @FetchRequest(sortDescriptors: []) var avatar: FetchedResults<Avatar>
    @State var showAlert = false
    @State var name:String = "Nickname"
    @State var SettingsViewisPresented = false
    @State private var s: String = ""
//    @State var apriSheet: Bool = false
    @State var apriSheet1: Bool = false
    var body: some View {
//        NavigationView{
            ZStack{
//                LinearGradient(gradient: Gradient(colors: [.purple, .black]), startPoint: .top, endPoint: .bottom)
//                    .ignoresSafeArea()
                LinearGradient(gradient: Gradient(colors: [.black, .purple]), startPoint: .top, endPoint: .bottom)
                    .ignoresSafeArea()
                .onTapGesture {
                        UserDefaults.standard.set(name,forKey: "inome")
                    }
                
                VStack{
                    Image(icona)
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: 130, height: 130)
                        .clipShape(Circle())
                        .background(Circle().fill(Color.white).opacity(0.8))
                        .padding(.top,-250)
                    HStack(alignment: .center){
                        Text(testo)
                            .foregroundColor(.white)
                            .font(.title)
                            .bold()
                        //                            .padding(.leading,65.5)
                            .padding(.top,-100)
                            .padding(.bottom,40)
                    }
                    
                    HStack(alignment: .center){
                        Text("My collection")
                            .font(.title)
                        
                        
                        NavigationLink(destination: AvatarChoiceView()) {
                            Text("View all")
                                .padding(.leading,100)
                            
                        }
                    }
                    .foregroundColor(.white)
                    ScrollView(.horizontal){
                        HStack{
                            ForEach(avatar){it in
                                Button {
                                    showAlert.toggle()
                                    print(it.imageName!)
                                    s=it.imageName ?? " "
                                } label: {
                                    Image(it.imageName!
                                    )
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(width: 100, height: 100)
                                    .clipShape(Circle())
                                    .background(Circle().fill(Color.white).opacity(0.8))
                                    .padding(12)
                                }
                                .alert("Changing picture", isPresented: $showAlert) {
                                    Button("Yes",role: .cancel){
                                        icona=s
                                        UserDefaults.standard.set(icona,forKey: "icona")
                                    }
                                    Button("Cancel",role: .destructive){}
                                } message: {
                                    Text("Vuoi cambiare avatar?")
                                }
                            }
                        }
                    }.onAppear(){
                        icona = UserDefaults.standard.string(forKey: "icona")  ?? ""
                    }
                    Button{
                    }label: {
                        
                        ZStack{
                            Rectangle()
                                .frame(width: 300,height: 60)
                                .foregroundColor(.black)
                                .cornerRadius(100)
                                .opacity(0.3)
                            NavigationLink("Shop Now", destination: BuyView())
                                .foregroundColor(.white)
                                .font(.headline)
                        }
                    }.padding(.top,150)
                    
                }.padding(.top,240)
//                    .onAppear(){
//                        inputText = UserDefaults.standard.string(forKey: "TEXT_KEY")  ?? ""
//                    }
                
            }.navigationBarItems( trailing: Button(action: {
                self.apriSheet1.toggle()
            }, label: {
                if showEdit{
                    Text("Edit name")
                }
//                    .padding(.top,-53)
            }))
            
//                    .onAppear(){
//                        cambioTesto = UserDefaults.standard.string(forKey: "TEXT_KEY") ?? ""
//
//        }
        .sheet(isPresented: $apriSheet1,content:  {
            ZStack{
                LinearGradient(gradient: Gradient(colors: [.purple, .black]), startPoint: .top, endPoint: .bottom)
                    .ignoresSafeArea()
                Form {
                    
                    Section (header: Text ("Change your nickname:" )) {
                        TextField("Add some text here.", text: $inputText)
                    }
                    Section (header: Text ("Actions:")) {
                    Button("Save Name") {
//                        cambioTesto=inputText
//                    UserDefaults.standard.set(cambioTesto, forKey: "TEXT_KEY")
                        testo = inputText
                   
                    
                    }
                    
                    }
                    Section (header: Text ("Close")) {
                    Button("Close Sheet") {
                        self.apriSheet1.toggle()
                   
                    
                    }
                    
                    }
                    
                }
            } .presentationDetents([ .medium, .fraction (0.50)])
        }).onAppear(){
            showEdit = true
        }.onDisappear(){
            showEdit=false
        }
        
    }
}
    
    
    
    struct ProfileView_Previews: PreviewProvider {
        static var previews: some View {
            ProfileView()
        }
    }
