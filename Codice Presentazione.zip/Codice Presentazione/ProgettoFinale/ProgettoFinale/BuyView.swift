//
//  DeleteView.swift
//  AvatarChoice
//
//  Created by Michele Valentino on 09/12/22.
//

import SwiftUI
import Foundation
import CoreData

struct BuyView: View {
    
    @Environment (\.managedObjectContext) var managedObjContext
    @FetchRequest(sortDescriptors: []) var avatar: FetchedResults<Avatar>
    
    @ObservedObject var myData = sharedData1
    
    var defaults = UserDefaults.standard
    @State var balance = UserDefaults.standard.integer(forKey: "Bilancio")
   
    @State var showAlert = false
    @State var showAlert1 = false
    @State private var s: String = ""
    @State var selectedAvatar = ""
    @State var selectedAvatarPrice = 0

    
    @State var listOfBuyedAvatar:[String] = []
   
    let columns: [GridItem] = [
        GridItem(.fixed(120), spacing: nil, alignment: nil),
        GridItem(.fixed(120), spacing: nil, alignment: nil),
        GridItem(.fixed(120), spacing: nil, alignment: nil)
    ]
        
    var body: some View {
            ZStack{
                LinearGradient(gradient: Gradient(colors: [.black, .purple]), startPoint: .top, endPoint: .bottom)
                    .ignoresSafeArea()
                
                VStack(alignment: .leading){
                    Text("Shop")
                        .font(.title)
                        .bold()
                        .padding(.top,-80)
                        .padding(.leading,30)
                        .foregroundColor(.white)
                    VStack(alignment: .center){
                        
                        Text("Your Balance: \(balance)")
                            .foregroundColor(.white)
                            .font(.title)
                            .padding(.top,-30)
                            .padding(.leading,80)
                        
                    }
                    
                    
                    ScrollView(){
                        LazyVGrid(columns: columns){
                            
                            ForEach(myData.store){it in
                                if !listOfBuyedAvatar.contains(it.imageStoreName){
                                    
                                Button {
                                    print("button")
                                    print(it.imageStoreName)
                                    print(myData.store)
                                    if(balance>=it.price){
                                        showAlert.toggle()
                                        print(it.imageStoreName)
                                        s=it.imageStoreName
                                        selectedAvatar = it.imageStoreName
                                        selectedAvatarPrice = it.price
                                    }
                                    else
                                    {
                                        showAlert1.toggle()
                                    }
                                } label: {
                                    VStack{
                                        Image(it.imageStoreName)
                                            .resizable()
                                            .aspectRatio(contentMode: .fit)
                                            .frame(width: 100, height: 100)
                                            .clipShape(Circle())
                                            .background(Circle().fill(Color.white).opacity(0.8))
                                            .padding(12)
                                        HStack{
                                            Text("Price: \(it.price)")
                                                .foregroundColor(.white)
                                        }
                                    }
                                }
                                .alert("Shop now", isPresented: $showAlert) {
                                    Button("Yes",role: .cancel){
                                        print("yes button")
                                        print(balance)
                                        print(it.price)
                                        balance = balance-selectedAvatarPrice
                                        print(balance)
                                        print(it.price)
                                        //                                          balance=balance+2000
                                        defaults.set(balance,forKey: "Bilancio")
                                        DataController().addImage(name: selectedAvatar, context: managedObjContext)
                                        listOfBuyedAvatar.append(selectedAvatar)
                                    }
                                    
                                    Button("Cancel",role: .destructive){}
                                    
                                } message: {
                                    Text("Do you want to confirm the purchase?")
                                }
                                
                                .alert("Insufficient Founds", isPresented: $showAlert1) {
                                    Button("Ok", role: .cancel){
                                    }
                                } message: {
                                    Text("Sorry you have not sufficient coins to buy it")
                                }
                            }}
                            }
                        }
                        .onAppear(){
                            listOfBuyedAvatar = avatarToString()
                            balance = UserDefaults.standard.integer(forKey: "Bilancio")
                        }
                        .frame(height: 490)
                    }
            }
        }
    
    
    func avatarToString()->[String]{
        var array:[String] = []
        for av in avatar{
            array.append(av.imageName ?? "")
        }
        return array
    }
    
}

struct BuyView_Previews: PreviewProvider {
    static var previews: some View {
        BuyView()
    }
}
