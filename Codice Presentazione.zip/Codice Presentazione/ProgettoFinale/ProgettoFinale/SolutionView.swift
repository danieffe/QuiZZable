//
//  SolutionView.swift
//  OurApp
//
//  Created by Davide Castaldi on 09/12/22.
//
import Foundation
import SwiftUI

struct SolutionView: View {
    
    @Environment(\.presentationMode) private var presentationMode
    @State var icona = UserDefaults.standard.string(forKey: "icona")  ?? ""
    @State var gotIt: Bool = false
    @State var questionSolution: String = ""
    var body: some View {
        
        ZStack {
            
            //background
            Color("darker purple")
                .ignoresSafeArea()
            Text("Wrong answer!")
                .font(.title)
                .foregroundColor(Color.white)
                .padding(.bottom, 650)
            //profile picture circle
            Circle()
                .fill(Color("darker purple"))
                .opacity(0.5)
                .frame(width: 120, height: 120)
                .padding(.bottom, 320)
            //Question mark above pp
            VStack {
                Image(systemName: "questionmark.bubble")
                    .font(.system(size: 60))
                    .foregroundColor(Color.white)
                    .padding(.leading, 150)
                    .padding(.bottom, 500)
            }
            //Question mark above pp flipped
            VStack {
                Image(systemName: "questionmark.bubble.ar")
                    .rotation3DEffect(.degrees(180), axis: (x: 0, y: 1, z: 0))
                    .font(.system(size: 60))
                    .foregroundColor(Color.white)
                    .padding(.leading, -110)
                    .padding(.bottom, 500)
            }
            //profile picture
            VStack {
                Image(icona)
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 105, height: 105)
                    .clipShape(Circle())
                    .shadow(radius: 20)
                    .padding(.bottom, 320)
            }
            //solution text
            Text(questionSolution)
                .font(.title2)
                .multilineTextAlignment(.center)
                .foregroundColor(Color.white)
                .padding(.top, 160)
            //white bar on top of the modal
            VStack {
                Capsule()
                    .fill(Color.white)
                    .frame(width: 50, height: 3)
                    .padding(10)
                    Spacer()
            }
            //container of "i got it" button
            Rectangle()
                .fill(Color("brighter purple")) //placeholder for true color
                .frame(width: 300, height: 80)
                .cornerRadius(40)
                .padding(.top, 600)
            //i got it button (it's a modal placeholder)
            VStack {
                Button {
                    self.presentationMode.wrappedValue.dismiss()
                } label: {
                    Text("I got it!")
                        .font(.title)
                        .foregroundColor(.white)
                        .frame(width: 280, height: 80)
                }
                .buttonStyle(.bordered)
                .controlSize(.small)
                .padding(.top, 600)
            }
        }
    }
}

struct SolutionView_Previews: PreviewProvider {
    static var previews: some View {
        SolutionView()
    }
}
