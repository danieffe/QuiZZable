//
//  WelcomeView.swift
//  Task3
//
//  Created by Annalisa Librera on 14/12/22.
//

import Foundation
import SwiftUI
import CoreData

struct WelcomeView: View {
    @Environment (\.managedObjectContext) var managedObjContext
    @FetchRequest(sortDescriptors: []) var avatar: FetchedResults<Avatar>
    @State var icona = UserDefaults.standard.string(forKey: "icona")  ?? ""
    @State var foo: Int = 0
    var body: some View {
        
        NavigationView{
            ZStack{
                
                LinearGradient(gradient: Gradient(colors: [.black, .purple]), startPoint: .top, endPoint: .bottom)
                    .ignoresSafeArea()
                Image("star")
                    .resizable()
                    .frame(width: 500,height: 500,alignment:.topTrailing)
                    .padding(.bottom,100)
                    .padding()
                VStack{
                    HStack{
                        Text("Welcome back!")
                            .foregroundColor(.white)
                            .font(.title)
                            .bold()
                            .frame(width: 280,height: 10, alignment: .leading)
                            .padding(.bottom,100)
                        
                        NavigationLink(destination: ProfileView()) {
                            if(icona==""){Image(systemName: "person.crop.circle.fill")
                                    .resizable()
                                    .foregroundColor(.white)
                                    .aspectRatio(contentMode: .fill)
                                    .foregroundColor(.white)
                                    .frame(width: 60, height: 60)
                                    .clipShape(Circle())
                                .background(Circle().fill(Color.black).opacity(0.8))}
                            else{Image(icona)
                                    .resizable()
                                    .aspectRatio(contentMode: .fill)
                                    .frame(width: 60, height: 60)
                                    .clipShape(Circle())
                                .background(Circle().fill(Color.white).opacity(0.8))}}
                        .padding(.top, -80)
                        .onAppear(){
                            icona = UserDefaults.standard.string(forKey: "icona")  ?? ""
                        }
                    }
    
                    ZStack{
                        Rectangle()
                            .frame(width: 280,height: 80, alignment: .center)
                            .foregroundColor(.black)
                            .opacity(0.5)
                        VStack{
                            Text("Have fun")
                                .foregroundColor(.white)
                                .frame(width: 300, alignment: .top)
                                .font(.title2)
                                
                                
                            Text("testing yourself!")
                                .foregroundColor(.white)
                                .frame(width: 300, alignment: .top)
                                .font(.title2)
                                
                                
                        }
                        
                    }
                    
                    
                    Image("astro")
                        .resizable()
                        .frame(width: 200,height: 180,alignment:.bottomTrailing)
                        .padding(.leading,80)

                    
                    ZStack{
                        Rectangle()
                            .foregroundColor(.black)
                            .opacity(0.5)
                            .frame(width: 370,height: 130)
                            .cornerRadius(30)
                        VStack{

                            
                                    NavigationLink(destination: GameView(questionIndex: $foo, equations: linearEquations.equationsArray[0])){
                                        ZStack{
                                            Rectangle()
                                                .frame(width: 320,height: 90, alignment: .center)
                                                .foregroundColor(.purple)
                                                .cornerRadius(20)
                                                .shadow(radius: 10)
                                                .opacity(0.9)
                                            
                                            Text("LET'S PLAY")
                                                .font(.title)
                                                .frame(alignment: .trailing)
                                                .foregroundColor(.white)
                                        }
                                    
                                
                            }
                            
                        }
                    }.padding(.top,100)
                    
                }
            }
        }.navigationBarBackButtonHidden(true)
    }
}

struct WelcomeView_Previews: PreviewProvider {
    static var previews: some View {
        WelcomeView()
    }
}
