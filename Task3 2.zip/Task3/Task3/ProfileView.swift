//
//  ProfileView.swift
//  Task3
//
//  Created by Annalisa Librera on 09/12/22.
//

import Foundation
import SwiftUI

var TokenAcc: Int = 0

struct ProfileView: View {
    var body: some View {
        ZStack{
            Image("sfondo")
            VStack{
                    Image("profilepic")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: 100,height: 100)
                        .clipShape(Circle())
                    Text("Nickname")
                        .frame(width: 160,height: 60,alignment: .center)
                        .foregroundColor(.white)
                        .font(.title)
                        .bold()
                
//       DA AGGIUNGERE LA PARTE DI DANIELE
                
                HStack{
                    Text("Balance:")
                        .font(.largeTitle)
                        .foregroundColor(.white)
                        .bold()
                        .frame(width: 140,height: 40,alignment: .bottomLeading)
                    Text("10")
                        .frame(width: 90,height: 40,alignment: .trailing)
                        .font(.largeTitle)
                        .foregroundColor(.white)
                        .bold()
                    Image("TOKEN")
                        .resizable()
                        .frame(width: 40,height: 40)
                }
                .padding(40)
                
                Image("coints")
                    .resizable()
                    .frame(width: 410,height: 240)
                    .padding(30)
                    Button{
                    }label: {
                        ZStack{
                        Rectangle()
                            .frame(width: 300,height: 60)
                            .foregroundColor(.black)
                            .cornerRadius(100)
                            .opacity(0.3)
                        Text("Shop Now")
                            .foregroundColor(.white)
                            .font(.headline)
                        }
                    }
                
                }
            }
        }
}

struct ProfileView_Previews: PreviewProvider {
    static var previews: some View {
        ProfileView()
    }
}
