//
//  DefinitivoFinaleApp.swift
//  DefinitivoFinale
//
//  Created by Michele Valentino on 15/12/22.
//

import SwiftUI
import Foundation
import CoreData

@main
struct DefinitivoFinaleApp: App {
    @State var board = UserDefaults.standard.integer(forKey: "board")
    @StateObject private var dataController = DataController()
    var body: some Scene {
        
        WindowGroup {
            if board == 0{
                OnBoardView()
                    .environment(\.managedObjectContext,
                                  dataController.container.viewContext)
            }else{
                WelcomeView()
                    .environment(\.managedObjectContext,
                                  dataController.container.viewContext)
            }
        }
    }
}
