//
//  GameView.swift
//  OurApp
//
//  Created by Davide Castaldi on 07/12/22.
//

import SwiftUI

struct GameView: View {
    
    @ObservedObject var myEquation = linearEquations
    
    var equation: Game
    var body: some View {
        
        ZStack  {
            Color(.black)
                .opacity(0.8)
    
            //Where the question and answer will be placed
            Rectangle()
                .fill(Color(.orange)) // placeholder for true color
                .frame(width: 300, height: 550)
                .cornerRadius(40)
                .offset(x: 0, y: -35)
                .padding()
            
            //THESE ARE FOR ANSWERS
            Group {
                //Answer 1
                Rectangle()
                    .fill(Color(.white)) // placeholder for true color
                    .frame(width: 250, height: 55)
                    .cornerRadius(40)
                    .offset(x: 0, y: -60)
                    .padding()
                
                //Answer 2
                Rectangle()
                    .fill(Color(.white)) // placeholder for true color
                    .frame(width: 250, height: 55)
                    .cornerRadius(40)
                    .offset(x: 0, y: 20)
                    .padding()
                
                //Answer 3
                Rectangle()
                    .fill(Color(.white)) // placeholder for true color
                    .frame(width: 250, height: 55)
                    .cornerRadius(40)
                    .offset(x: 0, y: 100)
                    .padding()
                
                //Answer 4
                Rectangle()
                    .fill(Color(.white)) // placeholder for true color
                    .frame(width: 250, height: 55)
                    .cornerRadius(40)
                    .offset(x: 0, y: 180)
                    .padding()
            }
            //this is the continue button
            Rectangle()
                .fill(Color(.orange)) // placeholder for true color
                .frame(width: 300, height: 80)
                .cornerRadius(40)
                .offset(x: 0, y: 305)
                .padding()
            
            //profile picture
            Circle()
                .fill(Color(.orange))
                .frame(width: 120, height: 120)
                .offset(x: 0, y: -300)
                .padding()
            
            VStack{
                
                //question
                Text(equation.question)
                    .font(.title2)
                    .multilineTextAlignment(.center)
                    .foregroundColor(.black)
                    .offset(x: 0 , y: -40)
                
                Text("x = 5")
                    .font(.title3)
                    .multilineTextAlignment(.center)
                    .foregroundColor(.black)
                    .offset(x: 0 , y: 30)
                
                Text("x = 1")
                    .font(.title3)
                    .multilineTextAlignment(.center)
                    .foregroundColor(.black)
                    .offset(x: 0 , y: 85)
                
                Text("x = -3")
                    .font(.title3)
                    .multilineTextAlignment(.center)
                    .foregroundColor(.black)
                    .offset(x: 0 , y: 140)
                
                Text("x = 0")
                    .font(.title3)
                    .multilineTextAlignment(.center)
                    .foregroundColor(.black)
                    .offset(x: 0 , y: 195)
                
                //self-explainatory
                Text("Continue")
                    .font(.title)
                    .offset(x: 0, y: 290)
                
                Image("pp1")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 105, height: 105)
                    .clipShape(Circle())
                    .shadow(radius: 20)
                    .offset(x: 0, y: -420)
                    .padding()
                
                    
                    
            }
            
                
        }
        
        
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct GameView_Previews: PreviewProvider {
    static var previews: some View {
        GameView(equation: linearEquations.equationsArray[0])
    }
}
