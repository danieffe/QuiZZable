//
//  ProfileView.swift
//  Task3
//
//  Created by Annalisa Librera on 09/12/22.
//

import Foundation
import SwiftUI

var TokenAcc: Int = 0

struct ProfileView: View {
    @State var name: String = "Nickname"
    @State var SettingsViewisPresented = false
    
    var body: some View {
        NavigationView{
            ZStack{
                LinearGradient(gradient: Gradient(colors: [.purple, .black]), startPoint: .top, endPoint: .bottom)
                                        .ignoresSafeArea()
                NavigationLink(destination: SettingsView()){ Image(systemName: "info.circle")
                        .foregroundColor(.white)
                        .frame(width: 350, height: 750, alignment: .topTrailing)
                        .font(.title2)
                        .padding()
                    }
                
                VStack{
                        Image("profilepic")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 100,height: 100, alignment: .bottom)
                            .clipShape(Circle())

                    HStack{
                        TextField("", text:$name)
                            .frame(width: 180,height: 35, alignment: .top)
                            .foregroundColor(.white)
                            .font(.title)
                            .bold()
                            .padding(.leading,30)
                                                
                        Image(systemName: "pencil")
                            .foregroundColor(.white)
                            .frame(alignment: .trailing)
                            .padding(.leading,-40)

                    }
                    .padding(40)
                        
                    HStack{
                        Text("Balance: ")
                            .foregroundColor(.white)
                            .font(.title)
                            .bold()
                            .frame(width: 200, alignment: .leading)
                        Image("TOKEN")
                            .resizable()
                            .frame(width: 40,height: 40)
                    }
                    .padding(30)
                    
                    Image("coints")
                        .resizable()
                        .frame(width: 410,height: 260)
                        .padding(30)
                        Button{
                        }label: {
                            ZStack{
                            Rectangle()
                                .frame(width: 300,height: 60)
                                .foregroundColor(.black)
                                .cornerRadius(100)
                                .opacity(0.3)
                            Text("Shop Now")
                                .foregroundColor(.white)
                                .font(.headline)
                            }
                        }
                    
                    }
                }
        }
        
        }
}

struct ProfileView_Previews: PreviewProvider {
    static var previews: some View {
        ProfileView()
    }
}
