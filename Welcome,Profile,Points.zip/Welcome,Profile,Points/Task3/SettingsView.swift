//
//  WelcomeView.swift
//  Task3
//
//  Created by Annalisa Librera on 12/12/22.
//

import Foundation
import SwiftUI

struct SettingsView: View{
    var body: some View{
        ZStack{
            LinearGradient(gradient: Gradient(colors: [.purple, .black]), startPoint: .top, endPoint: .bottom)
                                    .ignoresSafeArea()
            .ignoresSafeArea()
            VStack{
                Text("If you need help you can contact us at:")
                    .font(.title)
                    .frame(width: 370)
                    .foregroundColor(.white)
                Text("uncharged@icloud.com")
                    .font(.title2)
                
            }
            }
        }
    }

struct SettingsView_Previews: PreviewProvider {
    static var previews: some View {
        SettingsView()
    }
}
