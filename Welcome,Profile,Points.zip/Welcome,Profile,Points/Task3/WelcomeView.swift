//
//  WelcomeView.swift
//  Task3
//
//  Created by Annalisa Librera on 14/12/22.
//

import Foundation
import SwiftUI

struct WelcomeView: View {
    var body: some View {
        NavigationView{
            ZStack{
                
                LinearGradient(gradient: Gradient(colors: [.purple, .black]), startPoint: .top, endPoint: .bottom)
                    .ignoresSafeArea()
                Image("star")
                    .resizable()
                    .frame(width: 400,height: 360,alignment:.topTrailing)
                    .padding(.bottom,300)
                    .padding()
                VStack{
                    HStack{
                        Text("Welcome back!")
                            .foregroundColor(.white)
                            .font(.title)
                            .frame(width: 280,height: 10, alignment: .leading)
                            .padding(.bottom,40)
                        
                        Image("profilepic")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 50,height: 50, alignment: .bottom)
                            .clipShape(Circle())
                            .padding(.bottom,40)
                    }
    
                    ZStack{
                        Rectangle()
                            .frame(width: 280,height: 80, alignment: .center)
                            .foregroundColor(.black)
                            .opacity(0.5)
                        VStack{
                            Text("Have fun")
                                .foregroundColor(.white)
                                .frame(width: 300, alignment: .top)
                                .font(.title2)
                                
                                
                            Text("testing yourself!")
                                .foregroundColor(.white)
                                .frame(width: 300, alignment: .top)
                                .font(.title2)
                                
                                
                        }
                        
                    }
                    
                    
                    Image("astro")
                        .resizable()
                        .frame(width: 200,height: 180,alignment:.bottomTrailing)
                        .padding(.leading,80)
                    
                    Text("Play with us:")
                        .foregroundColor(.white)
                        .font(.title)
                        .frame(width: 340,height: 20, alignment: .leading)
                        .bold()
                        .padding(30)
                    
                    ZStack{
                        Rectangle()
                            .foregroundColor(.indigo)
                            .opacity(0.3)
                            .frame(width: 370,height: 270)
                            .cornerRadius(30)
                        VStack{
                            ZStack{
                                Rectangle()
                                    .frame(width: 320,height: 90, alignment: .center)
                                    .foregroundColor(.purple)
                                    .cornerRadius(20)
                                    .opacity(0.9)
                                    .shadow(radius: 10)
                                    .padding(10)
                                HStack{
                                    Image(systemName: "ellipsis.curlybraces")
                                        .resizable()
                                        .frame(width: 40,height: 30)
                                        .foregroundColor(.white)
                                        .padding(.trailing,20)
                                    Text("Math Test")
                                        .frame(alignment: .trailing)
                                        .foregroundColor(.white)
                                }
                            }
                            ZStack{
                                Rectangle()
                                    .frame(width: 320,height: 90, alignment: .center)
                                    .foregroundColor(.purple)
                                    .cornerRadius(20)
                                    .shadow(radius: 10)
                                    .opacity(0.9)
                                HStack{
                                    Image(systemName: "sparkle")
                                        .resizable()
                                        .frame(width: 40,height: 30)
                                        .foregroundColor(.white)
                                        .padding(.trailing,20)
                                    
                                    Text("Physics Test")
                                        .frame(alignment: .trailing)
                                        .foregroundColor(.white)
                                    
                                }
                            }
                            
                        }
                    }
                    
                }
            }
        }
    }
}

struct WelcomeView_Previews: PreviewProvider {
    static var previews: some View {
        WelcomeView()
    }
}
