//
//  OurAppApp.swift
//  OurApp
//
//  Created by Davide Castaldi on 07/12/22.
//

import SwiftUI

@main
struct OurAppApp: App {
    @State var foo: Int = 0
    
    var body: some Scene {
        //to show the game view
        
        WindowGroup {
            
            GameView(questionIndex: $foo, equations: linearEquations.equationsArray[0])
        }
    }
}
